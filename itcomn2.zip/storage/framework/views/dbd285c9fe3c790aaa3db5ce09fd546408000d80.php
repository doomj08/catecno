
<?php $__env->startSection('content'); ?>


    <div class="content">
        <div class="title m-b-md">
            BIENVENIDO
        </div>
    </div>





<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CYFAT\catecno\resources\views/index.blade.php ENDPATH**/ ?>