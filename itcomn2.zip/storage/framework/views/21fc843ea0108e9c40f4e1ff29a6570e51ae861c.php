

<?php $__env->startSection('content'); ?>
    <tabla-component
            url="instituciones"
            titulo="INSTITUCIONES"
            :columnas="[
            {nombre:'id'    ,alias:'#'},
            {nombre:'nombre' ,alias:'NOMBRE DEL INSTITUTO'},
            {nombre:'updated_at' ,alias:'ÚLTIMA MODIFICACIÓN'},
        ]"
            :campos="[
            {nombre: 'nombre',                  alias:'nombre del instituto',   tipo: 'String', value:'',                                   class:'col-sm-12'},
            ]"
    ></tabla-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CYFAT\catecno\resources\views/instituciones/index.blade.php ENDPATH**/ ?>