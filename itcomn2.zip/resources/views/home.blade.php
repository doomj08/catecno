@extends('layouts.app')
@section('content')

    <welcome-component></welcome-component>





@endsection()






