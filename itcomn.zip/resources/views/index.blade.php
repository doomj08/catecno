@extends('layouts.panel')
@section('content')


    <div class="content">
        <div class="title m-b-md">
            BIENVENIDO
        </div>
    </div>





@endsection()






