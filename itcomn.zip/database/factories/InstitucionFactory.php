<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Institucion;
use Faker\Generator as Faker;

$factory->define(Institucion::class, function (Faker $faker) {
    return [
        //
    ];
});
