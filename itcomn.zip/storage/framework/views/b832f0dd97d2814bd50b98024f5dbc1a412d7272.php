<div class="modal fade" id="empresa">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span>Cerrar</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-row">



                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success" v-on:click="crear()">Guardar Nueva Empresa</button>
                <button type="button" class="btn btn-danger" v-on:click="borrartemporales()">Borrar campos</button>
            </div>

        </div>
    </div>

</div><?php /**PATH C:\laragon\www\CYFAT\catecno\resources\views/empresas/registrar.blade.php ENDPATH**/ ?>