

<?php $__env->startSection('content'); ?>
    <tabla-component
            url="empresas"
            titulo="EMPRESAS"
            :columnas="[
            {nombre:'id'    ,alias:'#'},
            {nombre:'razon_social' ,alias:'RAZÓN SOCIAL'},
            {nombre:'created_at' ,alias:'FECHA DE CREACIÓN'},
            {nombre:'updated_at' ,alias:'FECHA DE ACTUALIZACIÓN'},
            {nombre:'updated_at' ,alias:'FECHA DE ACTUALIZACIÓN'},
        ]"
            :campos="[
            {nombre: 'razon_social',                alias:'curso',          tipo: 'String', value:'',                  class:'col-sm-12'},
        ]"
    ></tabla-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CYFAT\catecno\resources\views/empresas/index.blade.php ENDPATH**/ ?>